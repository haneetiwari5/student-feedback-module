"""
Student Feedback Module - Flask Application
College Student Feedback Portal with SQLite backend.
"""

import sqlite3
import os
from datetime import datetime, timezone
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "feedback.db")

VALID_SUBJECTS = [
    "Data Structures",
    "Python Programming",
    "Discrete Structures",
    "Computer Organization",
    "Technical Communication",
    "Faculty Feedback",
]

MAX_FEEDBACK_LENGTH = 2000
MAX_NAME_LENGTH = 120
MAX_ROLL_LENGTH = 60


def init_db():
    """Create the feedback table if it doesn't exist."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS feedback (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            student_name  TEXT    NOT NULL,
            roll_number   TEXT    NOT NULL,
            subject       TEXT    NOT NULL,
            rating        INTEGER NOT NULL,
            message       TEXT    NOT NULL,
            submitted_at  TEXT    NOT NULL
        )
        """
    )
    conn.commit()
    conn.close()


def validate_submission(data):
    """
    Validate the submitted form data on the server side.
    Returns (errors_dict, cleaned_dict).
    """
    errors = {}

    # Student Name
    name = (data.get("student_name") or "").strip()
    if not name:
        errors["student_name"] = "Student name is required."
    elif len(name) > MAX_NAME_LENGTH:
        errors["student_name"] = f"Name must be {MAX_NAME_LENGTH} characters or fewer."

    # Roll Number
    roll = (data.get("roll_number") or "").strip()
    if not roll:
        errors["roll_number"] = "Roll number is required."
    elif len(roll) > MAX_ROLL_LENGTH:
        errors["roll_number"] = f"Roll number must be {MAX_ROLL_LENGTH} characters or fewer."

    # Subject
    subject = (data.get("subject") or "").strip()
    if subject not in VALID_SUBJECTS:
        errors["subject"] = "Please select a valid subject."

    # Rating
    raw_rating = data.get("rating")
    try:
        rating = int(raw_rating)
    except (TypeError, ValueError):
        rating = None
        errors["rating"] = "Please provide a rating between 1 and 5."
    if rating is not None and (rating < 1 or rating > 5):
        errors["rating"] = "Rating must be an integer between 1 and 5."

    # Feedback message
    message = (data.get("message") or "").strip()
    if not message:
        errors["message"] = "Feedback message is required."
    elif len(message) > MAX_FEEDBACK_LENGTH:
        errors["message"] = f"Feedback must be {MAX_FEEDBACK_LENGTH} characters or fewer."

    cleaned = {
        "student_name": name,
        "roll_number": roll,
        "subject": subject,
        "rating": rating,
        "message": message,
    }
    return errors, cleaned


@app.route("/")
def index():
    """Display the feedback page."""
    return render_template("index.html", subjects=VALID_SUBJECTS)


@app.route("/submit", methods=["POST"])
def submit_feedback():
    """Receive and process a feedback form submission."""
    data = request.get_json(silent=True)
    if data is None:
        # Fallback: accept form-encoded data too
        data = request.form.to_dict()

    errors, cleaned = validate_submission(data)

    if errors:
        return jsonify({"success": False, "errors": errors}), 400

    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO feedback
                (student_name, roll_number, subject, rating, message, submitted_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                cleaned["student_name"],
                cleaned["roll_number"],
                cleaned["subject"],
                cleaned["rating"],
                cleaned["message"],
                timestamp,
            ),
        )
        conn.commit()
        record_id = cursor.lastrowid
        conn.close()
    except sqlite3.Error:
        return jsonify(
            {"success": False, "errors": {"database": "A database error occurred. Please try again."}}
        ), 500

    return jsonify(
        {
            "success": True,
            "message": "Thank you! Your feedback has been submitted successfully.",
            "record_id": record_id,
            "submitted_at": timestamp,
        }
    ), 200


@app.route("/feedbacks")
def list_feedbacks():
    """Return all feedback records as JSON (for admin/viewing purposes)."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, student_name, roll_number, subject, rating, message, submitted_at "
        "FROM feedback ORDER BY id DESC"
    )
    rows = cursor.fetchall()
    conn.close()

    feedbacks = [dict(row) for row in rows]
    return jsonify({"success": True, "feedbacks": feedbacks, "count": len(feedbacks)})


init_db()  # Ensure the SQLite table exists when deployed with Gunicorn.

if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
