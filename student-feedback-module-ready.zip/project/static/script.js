/* ============================
   Student Feedback Portal
   Frontend Validation & UI
   ============================ */

(function () {
    "use strict";

    // --- DOM References ---
    const form              = document.getElementById("feedbackForm");
    const nameInput         = document.getElementById("studentName");
    const rollInput         = document.getElementById("rollNumber");
    const subjectSelect     = document.getElementById("subject");
    const messageTextarea   = document.getElementById("feedbackMessage");
    const starRating        = document.getElementById("starRating");
    const stars             = starRating.querySelectorAll(".star");
    const ratingPreview     = document.getElementById("ratingPreview");
    const charCounter       = document.getElementById("charCounter");
    const submitBtn         = document.getElementById("submitBtn");
    const resetBtn          = document.getElementById("resetBtn");
    const submitAnotherBtn  = document.getElementById("submitAnotherBtn");
    const confirmationSec   = document.getElementById("confirmationSection");
    const confirmationMsg   = document.getElementById("confirmationMessage");
    const confirmationMeta  = document.getElementById("confirmationMeta");
    const feedbackCard      = document.getElementById("feedbackCard");

    // --- State ---
    let currentRating = 0;
    let isSubmitting  = false;

    const MAX_CHARS = 2000;

    // --- Rating Labels ---
    const ratingLabels = {
        1: "Poor",
        2: "Fair",
        3: "Good",
        4: "Very Good",
        5: "Excellent",
    };

    // =============================================
    //  Star Rating Logic
    // =============================================
    stars.forEach(function (star) {
        // Click to set rating
        star.addEventListener("click", function () {
            currentRating = parseInt(star.dataset.value, 10);
            updateStars(currentRating);
            updateRatingPreview(currentRating);
            clearError("ratingError");
        });

        // Hover preview
        star.addEventListener("mouseenter", function () {
            const hoverValue = parseInt(star.dataset.value, 10);
            updateStars(hoverValue, true);
        });

        // Keyboard support
        star.addEventListener("keydown", function (e) {
            const value = parseInt(star.dataset.value, 10);
            if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                currentRating = value;
                updateStars(currentRating);
                updateRatingPreview(currentRating);
                clearError("ratingError");
            } else if (e.key === "ArrowRight" || e.key === "ArrowUp") {
                e.preventDefault();
                if (value < 5) {
                    stars[value].focus();
                }
            } else if (e.key === "ArrowLeft" || e.key === "ArrowDown") {
                e.preventDefault();
                if (value > 1) {
                    stars[value - 2].focus();
                }
            }
        });
    });

    starRating.addEventListener("mouseleave", function () {
        updateStars(currentRating);
    });

    function updateStars(value, isHover) {
        stars.forEach(function (star) {
            const starValue = parseInt(star.dataset.value, 10);
            star.classList.remove("filled", "hover-active");

            if (isHover) {
                if (starValue <= value) {
                    star.classList.add("hover-active");
                }
            } else {
                if (starValue <= value) {
                    star.classList.add("filled");
                }
                star.setAttribute("aria-checked", starValue === value ? "true" : "false");
            }
        });
    }

    function updateRatingPreview(value) {
        if (value > 0) {
            ratingPreview.textContent = value + " / 5 — " + ratingLabels[value];
            ratingPreview.classList.add("rated");
        } else {
            ratingPreview.textContent = "Click a star to rate";
            ratingPreview.classList.remove("rated");
        }
    }

    // =============================================
    //  Character Counter
    // =============================================
    messageTextarea.addEventListener("input", function () {
        const length = messageTextarea.value.length;
        charCounter.textContent = length + " / " + MAX_CHARS;

        charCounter.classList.remove("warn", "danger");
        if (length > MAX_CHARS * 0.9 && length <= MAX_CHARS) {
            charCounter.classList.add("warn");
        } else if (length >= MAX_CHARS) {
            charCounter.classList.add("danger");
        }
    });

    // =============================================
    //  Real-time field validation on blur
    // =============================================
    nameInput.addEventListener("blur", function () {
        if (nameInput.value.trim() === "") {
            showError("nameError", "Student name is required.", nameInput);
        } else {
            clearError("nameError");
            nameInput.classList.remove("input-error");
        }
    });

    rollInput.addEventListener("blur", function () {
        if (rollInput.value.trim() === "") {
            showError("rollError", "Roll number is required.", rollInput);
        } else {
            clearError("rollError");
            rollInput.classList.remove("input-error");
        }
    });

    subjectSelect.addEventListener("change", function () {
        if (subjectSelect.value) {
            clearError("subjectError");
            subjectSelect.classList.remove("input-error");
        }
    });

    messageTextarea.addEventListener("blur", function () {
        if (messageTextarea.value.trim() === "") {
            showError("messageError", "Feedback message is required.", messageTextarea);
        } else {
            clearError("messageError");
            messageTextarea.classList.remove("input-error");
        }
    });

    // =============================================
    //  Error Helpers
    // =============================================
    function showError(errorId, message, inputEl) {
        var errorEl = document.getElementById(errorId);
        errorEl.textContent = message;
        if (inputEl) {
            inputEl.classList.add("input-error");
        }
    }

    function clearError(errorId) {
        var errorEl = document.getElementById(errorId);
        errorEl.textContent = "";
    }

    function clearAllErrors() {
        clearError("nameError");
        clearError("rollError");
        clearError("subjectError");
        clearError("ratingError");
        clearError("messageError");
        nameInput.classList.remove("input-error");
        rollInput.classList.remove("input-error");
        subjectSelect.classList.remove("input-error");
        messageTextarea.classList.remove("input-error");
    }

    // =============================================
    //  Frontend Validation
    // =============================================
    function validateForm() {
        var errors = [];
        clearAllErrors();

        // Name
        if (nameInput.value.trim() === "") {
            showError("nameError", "Student name is required.", nameInput);
            errors.push("name");
        }

        // Roll number
        if (rollInput.value.trim() === "") {
            showError("rollError", "Roll number is required.", rollInput);
            errors.push("roll");
        }

        // Subject
        if (!subjectSelect.value) {
            showError("subjectError", "Please select a subject.", subjectSelect);
            errors.push("subject");
        }

        // Rating
        if (currentRating < 1 || currentRating > 5) {
            showError("ratingError", "Please select a rating between 1 and 5 stars.");
            errors.push("rating");
        }

        // Message
        if (messageTextarea.value.trim() === "") {
            showError("messageError", "Feedback message is required.", messageTextarea);
            errors.push("message");
        }

        return errors;
    }

    // =============================================
    //  Submit Handler
    // =============================================
    form.addEventListener("submit", function (e) {
        e.preventDefault();

        // Prevent duplicate submission
        if (isSubmitting) return;

        var errors = validateForm();
        if (errors.length > 0) {
            // Focus first field with error
            var firstErrorMap = {
                name:    nameInput,
                roll:    rollInput,
                subject: subjectSelect,
                rating:  stars[0],
                message: messageTextarea,
            };
            if (firstErrorMap[errors[0]]) {
                firstErrorMap[errors[0]].focus();
            }
            return;
        }

        // Enter loading state
        isSubmitting = true;
        setLoading(true);

        // Build payload
        var payload = {
            student_name: nameInput.value.trim(),
            roll_number:  rollInput.value.trim(),
            subject:      subjectSelect.value,
            rating:       currentRating,
            message:      messageTextarea.value.trim(),
        };

        fetch("/submit", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        })
            .then(function (response) {
                return response.json().then(function (data) {
                    return { ok: response.ok, body: data };
                });
            })
            .then(function (result) {
                if (result.ok && result.body.success) {
                    showConfirmation(result.body);
                } else {
                    // Show server-side errors
                    var serverErrors = result.body.errors || {};
                    if (serverErrors.student_name) {
                        showError("nameError", serverErrors.student_name, nameInput);
                    }
                    if (serverErrors.roll_number) {
                        showError("rollError", serverErrors.roll_number, rollInput);
                    }
                    if (serverErrors.subject) {
                        showError("subjectError", serverErrors.subject, subjectSelect);
                    }
                    if (serverErrors.rating) {
                        showError("ratingError", serverErrors.rating);
                    }
                    if (serverErrors.message) {
                        showError("messageError", serverErrors.message, messageTextarea);
                    }
                    if (serverErrors.database) {
                        showError("messageError", serverErrors.database, messageTextarea);
                    }
                }
            })
            .catch(function () {
                showError("messageError", "Network error. Please check your connection and try again.", messageTextarea);
            })
            .finally(function () {
                isSubmitting = false;
                setLoading(false);
            });
    });

    // =============================================
    //  Loading State
    // =============================================
    function setLoading(loading) {
        var btnText  = submitBtn.querySelector(".btn-text");
        var btnLoad  = submitBtn.querySelector(".btn-loader");

        if (loading) {
            submitBtn.disabled = true;
            btnText.hidden = true;
            btnLoad.hidden = false;
        } else {
            submitBtn.disabled = false;
            btnText.hidden = false;
            btnLoad.hidden = true;
        }
    }

    // =============================================
    //  Confirmation Display
    // =============================================
    function showConfirmation(responseData) {
        form.hidden = true;
        confirmationSec.hidden = false;

        confirmationMsg.textContent = responseData.message || "Thank you! Your feedback has been submitted successfully.";

        var metaParts = [];
        if (responseData.record_id) {
            metaParts.push("Reference ID: #" + responseData.record_id);
        }
        if (responseData.submitted_at) {
            metaParts.push("Submitted: " + responseData.submitted_at);
        }
        confirmationMeta.textContent = metaParts.join("  |  ");

        // Scroll to top of card
        feedbackCard.scrollIntoView({ behavior: "smooth", block: "start" });
    }

    // =============================================
    //  Reset Form
    // =============================================
    function resetForm() {
        form.reset();
        currentRating = 0;
        updateStars(0);
        updateRatingPreview(0);
        charCounter.textContent = "0 / " + MAX_CHARS;
        charCounter.classList.remove("warn", "danger");
        clearAllErrors();
    }

    resetBtn.addEventListener("click", function () {
        resetForm();
        nameInput.focus();
    });

    // =============================================
    //  Submit Another Feedback
    // =============================================
    submitAnotherBtn.addEventListener("click", function () {
        resetForm();
        confirmationSec.hidden = true;
        form.hidden = false;
        nameInput.focus();
        feedbackCard.scrollIntoView({ behavior: "smooth", block: "start" });
    });

})();
