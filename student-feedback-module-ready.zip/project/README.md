# Student Feedback Module

A responsive college Student Feedback Portal built with **Python, Flask, SQLite, HTML, CSS, and JavaScript**. Students can submit feedback for a subject or faculty member, provide a 1–5 rating, and receive a confirmation. Feedback is stored in a local SQLite database.

## Features

- Responsive student feedback form
- 1–5 star rating interface
- Client-side and server-side validation
- SQLite persistence for submitted feedback
- Submission confirmation with reference ID and timestamp
- JSON endpoint for viewing submitted feedback

## Tech stack

- Python 3.10+
- Flask
- SQLite
- HTML5, CSS3, JavaScript

## Project structure

```text
project/
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   └── index.html
└── static/
    ├── script.js
    └── style.css
```

## Run locally on Windows

1. Install Python 3 and Git.
2. Open this folder in VS Code (the folder containing `app.py` and `requirements.txt`).
3. Open **Terminal → New Terminal**.
4. Create and activate a virtual environment (recommended):

   ```powershell
   py -m venv .venv
   .venv\Scripts\Activate.ps1
   ```

5. Install dependencies:

   ```powershell
   py -m pip install -r requirements.txt
   ```

6. Start the app:

   ```powershell
   py app.py
   ```

7. Open <http://127.0.0.1:5000> in your browser.

If PowerShell blocks virtual-environment activation, skip activation and run `py -m pip install -r requirements.txt` directly.

## Deploy on Render

1. Push this folder's contents to a **public GitHub repository**.
2. In Render, choose **New → Web Service** and connect the repository.
3. Set **Root Directory** to blank if `app.py` is at repository root.
4. **Build Command:** `pip install -r requirements.txt`
5. **Start Command:** `gunicorn app:app`
6. Create the service and wait for the deploy to finish.

> Note: SQLite on a typical hosted service may not persist across redeploys/restarts unless a persistent disk is configured. For a long-term production deployment, use a managed database.

## Submission links

- GitHub repository: add your public repository URL here.
- Live deployment: add your deployed URL here.
