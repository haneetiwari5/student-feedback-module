import { useState, useRef, useEffect, useCallback } from 'react'
import {
  GraduationCap,
  Star,
  Send,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Loader2,
  User,
  Hash,
  BookOpen,
  MessageSquare,
  Clock,
  Tag,
} from 'lucide-react'
import { supabase } from './supabaseClient'

const SUBJECTS = [
  'Data Structures',
  'Python Programming',
  'Discrete Structures',
  'Computer Organization',
  'Technical Communication',
  'Faculty Feedback',
]

const MAX_CHARS = 500
const RATING_LABELS = ['', 'Poor', 'Fair', 'Good', 'Very Good', 'Excellent']

const INITIAL_FORM = {
  studentName: '',
  rollNumber: '',
  subject: '',
  rating: 0,
  message: '',
}

export default function App() {
  const [form, setForm] = useState(INITIAL_FORM)
  const [errors, setErrors] = useState({})
  const [hoverRating, setHoverRating] = useState(0)
  const [submitting, setSubmitting] = useState(false)
  const [success, setSuccess] = useState(null)
  const [recentFeedback, setRecentFeedback] = useState([])
  const [stats, setStats] = useState({ total: 0, avgRating: 0 })
  const textareaRef = useRef(null)

  const fetchRecentFeedback = useCallback(async () => {
    const { data, error } = await supabase
      .from('student_feedback')
      .select('id, student_name, roll_number, subject, rating, message, created_at')
      .order('created_at', { ascending: false })
      .limit(5)

    if (error) return

    setRecentFeedback(data || [])

    const { count } = await supabase
      .from('student_feedback')
      .select('*', { count: 'exact', head: true })

    const total = count || 0
    const avg =
      data && data.length > 0
        ? (data.reduce((s, r) => s + r.rating, 0) / data.length).toFixed(1)
        : '0.0'
    setStats({ total, avgRating: avg })
  }, [])

  useEffect(() => {
    fetchRecentFeedback()
  }, [fetchRecentFeedback])

  const validate = (data) => {
    const errs = {}

    if (!data.studentName || data.studentName.trim().length === 0) {
      errs.studentName = 'Student name is required.'
    } else if (data.studentName.trim().length < 2) {
      errs.studentName = 'Name must be at least 2 characters.'
    }

    if (!data.rollNumber || data.rollNumber.trim().length === 0) {
      errs.rollNumber = 'Roll number is required.'
    } else if (data.rollNumber.trim().length < 2) {
      errs.rollNumber = 'Please enter a valid roll number.'
    }

    if (!data.subject) {
      errs.subject = 'Please select a subject or teacher.'
    }

    if (!data.rating || data.rating < 1 || data.rating > 5) {
      errs.rating = 'Please select a rating from 1 to 5 stars.'
    }

    if (!data.message || data.message.trim().length === 0) {
      errs.message = 'Feedback message is required.'
    } else if (data.message.trim().length < 10) {
      errs.message = 'Feedback must be at least 10 characters.'
    } else if (data.message.length > MAX_CHARS) {
      errs.message = `Feedback must not exceed ${MAX_CHARS} characters.`
    }

    return errs
  }

  const handleChange = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev }
        delete next[field]
        return next
      })
    }
  }

  const handleRatingClick = (value) => {
    handleChange('rating', value)
  }

  const handleReset = () => {
    setForm(INITIAL_FORM)
    setErrors({})
    setHoverRating(0)
    setSuccess(null)
    if (textareaRef.current) textareaRef.current.style.height = 'auto'
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (submitting) return

    const errs = validate(form)
    setErrors(errs)

    if (Object.keys(errs).length > 0) {
      const firstErrorField = Object.keys(errs)[0]
      const el = document.querySelector(`[name="${firstErrorField}"]`)
      if (el) el.focus()
      return
    }

    setSubmitting(true)

    try {
      const { data, error } = await supabase
        .from('student_feedback')
        .insert({
          student_name: form.studentName.trim(),
          roll_number: form.rollNumber.trim(),
          subject: form.subject,
          rating: form.rating,
          message: form.message.trim(),
        })
        .select('id, created_at')
        .single()

      if (error) throw error

      setSuccess({
        id: data.id,
        timestamp: data.created_at,
        name: form.studentName.trim(),
        subject: form.subject,
        rating: form.rating,
      })

      setForm(INITIAL_FORM)
      setHoverRating(0)
      if (textareaRef.current) textareaRef.current.style.height = 'auto'
      fetchRecentFeedback()

      setTimeout(() => {
        document.getElementById('success-banner')?.scrollIntoView({
          behavior: 'smooth',
          block: 'center',
        })
      }, 100)
    } catch (err) {
      setErrors({
        submit:
          'Could not submit feedback. Please check your connection and try again.',
      })
    } finally {
      setSubmitting(false)
    }
  }

  const charCount = form.message.length
  const isNearLimit = charCount > MAX_CHARS * 0.85 && charCount <= MAX_CHARS
  const isAtLimit = charCount > MAX_CHARS

  const displayRating = hoverRating || form.rating

  return (
    <div className="app-bg">
      {/* Navbar */}
      <nav className="navbar" role="navigation" aria-label="Main navigation">
        <div className="navbar-logo">
          <GraduationCap size={26} color="#fff" strokeWidth={2} />
        </div>
        <div className="navbar-text">
          <span className="navbar-title">Student Feedback Portal</span>
          <span className="navbar-subtitle">College Feedback Management System</span>
        </div>
      </nav>

      {/* Hero */}
      <div className="hero">
        <h1>Share Your Feedback</h1>
        <p>Help us improve the learning experience. Your voice matters.</p>
      </div>

      {/* Stats */}
      <div className="stats-bar">
        <div className="stat-card">
          <div className="stat-value">{stats.total}</div>
          <div className="stat-label">Submissions</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.avgRating}</div>
          <div className="stat-label">Avg Rating</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{SUBJECTS.length}</div>
          <div className="stat-label">Subjects</div>
        </div>
      </div>

      {/* Form Card */}
      <div className="card-container">
        <div className="card">
          <div className="card-header">
            <h2>Feedback Form</h2>
            <p>All fields marked with an asterisk (*) are required.</p>
          </div>

          {success && (
            <div className="success-banner" id="success-banner" role="alert" aria-live="polite">
              <div className="success-icon-wrapper">
                <CheckCircle2 />
              </div>
              <h3>Thank you! Your feedback has been submitted successfully.</h3>
              <p>We appreciate you taking the time to share your thoughts.</p>
              <div className="success-details">
                <span>
                  <Tag size={14} /> {success.subject}
                </span>
                <span>
                  <Star size={14} fill="#fbbf24" color="#fbbf24" /> {success.rating}/5
                </span>
                <span>
                  <Clock size={14} />{' '}
                  {new Date(success.timestamp).toLocaleString('en-US', {
                    dateStyle: 'medium',
                    timeStyle: 'short',
                  })}
                </span>
              </div>
            </div>
          )}

          {errors.submit && (
            <div className="field-error" style={{ marginBottom: '1rem', padding: '0.75rem', background: 'var(--error-50)', borderRadius: '8px', border: '1px solid var(--error-100)' }}>
              <AlertCircle size={16} />
              <span>{errors.submit}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate>
            {/* Name & Roll Number */}
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="studentName" className="form-label">
                  <User size={14} style={{ display: 'inline', verticalAlign: 'middle', marginRight: '4px' }} />
                  Student Name<span className="required">*</span>
                </label>
                <input
                  type="text"
                  id="studentName"
                  name="studentName"
                  className={`form-input ${errors.studentName ? 'has-error' : ''}`}
                  value={form.studentName}
                  onChange={(e) => handleChange('studentName', e.target.value)}
                  placeholder="e.g. Rahul Sharma"
                  maxLength={80}
                  autoComplete="off"
                  aria-invalid={!!errors.studentName}
                  aria-describedby={errors.studentName ? 'error-studentName' : undefined}
                />
                {errors.studentName && (
                  <div className="field-error" id="error-studentName">
                    <AlertCircle size={14} />
                    <span>{errors.studentName}</span>
                  </div>
                )}
              </div>

              <div className="form-group">
                <label htmlFor="rollNumber" className="form-label">
                  <Hash size={14} style={{ display: 'inline', verticalAlign: 'middle', marginRight: '4px' }} />
                  Roll Number<span className="required">*</span>
                </label>
                <input
                  type="text"
                  id="rollNumber"
                  name="rollNumber"
                  className={`form-input ${errors.rollNumber ? 'has-error' : ''}`}
                  value={form.rollNumber}
                  onChange={(e) => handleChange('rollNumber', e.target.value)}
                  placeholder="e.g. CS21B001"
                  maxLength={30}
                  autoComplete="off"
                  aria-invalid={!!errors.rollNumber}
                  aria-describedby={errors.rollNumber ? 'error-rollNumber' : undefined}
                />
                {errors.rollNumber && (
                  <div className="field-error" id="error-rollNumber">
                    <AlertCircle size={14} />
                    <span>{errors.rollNumber}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Subject */}
            <div className="form-group">
              <label htmlFor="subject" className="form-label">
                <BookOpen size={14} style={{ display: 'inline', verticalAlign: 'middle', marginRight: '4px' }} />
                Select Subject / Teacher<span className="required">*</span>
              </label>
              <select
                id="subject"
                name="subject"
                className={`form-select ${errors.subject ? 'has-error' : ''}`}
                value={form.subject}
                onChange={(e) => handleChange('subject', e.target.value)}
                aria-invalid={!!errors.subject}
                aria-describedby={errors.subject ? 'error-subject' : undefined}
              >
                <option value="">-- Choose a subject or teacher --</option>
                {SUBJECTS.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
              {errors.subject && (
                <div className="field-error" id="error-subject">
                  <AlertCircle size={14} />
                  <span>{errors.subject}</span>
                </div>
              )}
            </div>

            {/* Star Rating */}
            <div className="form-group">
              <span className="form-label" id="rating-label">
                Rating<span className="required">*</span>
              </span>
              <div className="star-rating" role="radiogroup" aria-labelledby="rating-label">
                <div className="stars-container">
                  {[1, 2, 3, 4, 5].map((val) => (
                    <button
                      type="button"
                      key={val}
                      className="star-btn"
                      onClick={() => handleRatingClick(val)}
                      onMouseEnter={() => setHoverRating(val)}
                      onMouseLeave={() => setHoverRating(0)}
                      aria-label={`${val} star${val > 1 ? 's' : ''}`}
                      role="radio"
                      aria-checked={form.rating === val}
                      tabIndex={form.rating === val ? 0 : -1}
                    >
                      <Star
                        className={`star-icon ${val <= displayRating ? 'filled' : ''}`}
                      />
                    </button>
                  ))}
                </div>
                <div className="star-preview">
                  {displayRating > 0 ? (
                    <>
                      <span className="star-preview-value">{displayRating}/5</span> — {RATING_LABELS[displayRating]}
                    </>
                  ) : (
                    'Click a star to rate'
                  )}
                </div>
              </div>
              {errors.rating && (
                <div className="field-error">
                  <AlertCircle size={14} />
                  <span>{errors.rating}</span>
                </div>
              )}
            </div>

            {/* Feedback Message */}
            <div className="form-group">
              <label htmlFor="message" className="form-label">
                <MessageSquare size={14} style={{ display: 'inline', verticalAlign: 'middle', marginRight: '4px' }} />
                Feedback Message<span className="required">*</span>
              </label>
              <textarea
                ref={textareaRef}
                id="message"
                name="message"
                className={`form-textarea ${errors.message ? 'has-error' : ''}`}
                value={form.message}
                onChange={(e) => handleChange('message', e.target.value)}
                placeholder="Share your thoughts about the teaching, course content, lab sessions, or any suggestions for improvement..."
                maxLength={MAX_CHARS}
                rows={5}
                aria-invalid={!!errors.message}
                aria-describedby={errors.message ? 'error-message' : 'char-counter'}
              />
              <div className="char-counter">
                <span className="char-counter-hint">
                  {errors.message ? (
                    <span style={{ color: 'var(--error-600)' }}>{errors.message}</span>
                  ) : (
                    'Minimum 10 characters'
                  )}
                </span>
                <span
                  className={`char-counter-text ${isAtLimit ? 'at-limit' : isNearLimit ? 'near-limit' : ''}`}
                  id="char-counter"
                >
                  {charCount} / {MAX_CHARS}
                </span>
              </div>
            </div>

            {/* Buttons */}
            <div className="button-row">
              <button
                type="button"
                className="btn btn-secondary"
                onClick={handleReset}
                disabled={submitting}
              >
                <RotateCcw size={18} />
                Reset Form
              </button>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={submitting}
              >
                {submitting ? (
                  <>
                    <Loader2 size={18} className="spinner" />
                    Submitting...
                  </>
                ) : (
                  <>
                    <Send size={18} />
                    Submit Feedback
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Recent Feedback */}
      {recentFeedback.length > 0 && (
        <div className="feedback-list-section" style={{ marginTop: '2.5rem' }}>
          <h3>Recent Feedback</h3>
          <div className="feedback-list">
            {recentFeedback.map((item) => (
              <div className="feedback-item" key={item.id}>
                <div className="feedback-item-avatar">
                  {item.student_name.charAt(0).toUpperCase()}
                </div>
                <div className="feedback-item-body">
                  <div className="feedback-item-header">
                    <span className="feedback-item-name">
                      {item.student_name}
                    </span>
                    <div className="feedback-item-stars">
                      {[1, 2, 3, 4, 5].map((v) => (
                        <Star
                          key={v}
                          size={14}
                          className={v <= item.rating ? 'star-icon filled' : 'star-icon'}
                        />
                      ))}
                    </div>
                  </div>
                  <div className="feedback-item-meta">
                    {item.roll_number} · {item.subject} ·{' '}
                    {new Date(item.created_at).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                  </div>
                  <div className="feedback-item-message">{item.message}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <footer className="footer">
        Student Feedback Portal &copy; 2026 · Built for B.Tech College Assignment
      </footer>
    </div>
  )
}
