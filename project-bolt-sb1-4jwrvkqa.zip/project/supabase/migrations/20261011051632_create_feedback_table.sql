/*
# Create student_feedback table (single-tenant, no auth)

## Purpose
Stores student feedback submissions for a college feedback module.

## New Tables
- `student_feedback`
  - `id` (uuid, primary key, auto-generated)
  - `student_name` (text, not null) — name of the student
  - `roll_number` (text, not null) — student roll number
  - `subject` (text, not null) — subject or teacher selected
  - `rating` (integer, not null, 1–5) — star rating
  - `message` (text, not null) — the feedback message
  - `created_at` (timestamptz, default now()) — submission timestamp

## Security
- Row Level Security enabled.
- This is a single-tenant app with no sign-in, so all CRUD is allowed
  for both `anon` and `authenticated` roles. The data is intentionally
  public/shared for this feedback portal.
*/

CREATE TABLE IF NOT EXISTS student_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_name text NOT NULL,
  roll_number text NOT NULL,
  subject text NOT NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE student_feedback ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_feedback" ON student_feedback;
CREATE POLICY "anon_select_feedback" ON student_feedback
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_feedback" ON student_feedback;
CREATE POLICY "anon_insert_feedback" ON student_feedback
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_feedback" ON student_feedback;
CREATE POLICY "anon_update_feedback" ON student_feedback
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_feedback" ON student_feedback;
CREATE POLICY "anon_delete_feedback" ON student_feedback
  FOR DELETE TO anon, authenticated USING (true);